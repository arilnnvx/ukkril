<nav class="navbar bg-white navbar-expand-lg bg-body-tertiary  position-fixed z-3 mm-t">
    <div class="header bg-white d-flex justify-content-between align-items-center border">
        <div class="right d-flex">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <p class="main-text">galeri</p>
            <p>foto aril</p>
        </div>
        <div class="left d-flex">
            <div class="container-fluid">
                <!-- <div class="collapse navbar-collapse">
                    <ul class="navbar-nav  my-2 my-lg-0" style="--bs-scroll-height: 100px;">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Link
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                            </ul>
                        </li>
                    </ul>
                </div> -->
            </div>
            <button type="button" class="btn btn-l pp"><a href="../">Home</a></button>
            <button type="button" class="btn btn-l pp"><a href="../login/logout">Logout</a></button>
            <div class="circle">
                <div class="in-circle">
                    <img width="45px" height="45px" src="../img/logo.webp" alt="" />
                </div>
            </div>
        </div>
    </div>
</nav>