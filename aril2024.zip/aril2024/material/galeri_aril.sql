-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2024 at 08:57 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galeri_aril`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `AlbumID` int(11) NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(27, 'goop', 'lorem ipsum dolor sit amer', '2024-03-04', 36),
(28, 'qq', 'qqq', '2024-03-04', 36),
(29, 'duu', 'ssss', '2024-04-17', 38),
(30, 'duu', 'sssssssssssss', '2024-04-17', 41),
(31, 'ddd', 'dd', '2024-04-17', 42),
(32, 'duu', 'segar enak', '2024-04-17', 43),
(33, 'we', 'qqqq', '2024-04-17', 43);

-- --------------------------------------------------------

--
-- Table structure for table `foto`
--

CREATE TABLE `foto` (
  `FotoID` int(11) NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(255) NOT NULL,
  `AlbumID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(19, '', 'aaaa', '2024-03-04', '1.jpg', 27, 36),
(15, '', 'lorem ipsum dolor sit amer', '2024-03-04', '1.jpg', 27, 36),
(16, '', 'lorem ipsum dolor sit amer', '2024-03-04', 'f4.webp', 27, 36),
(17, '', 'lorem ipsum dolor sit amer', '2024-03-04', 'desa2.jpg', 27, 36),
(18, '', 'lorem ipsum dolor sit amer', '2024-03-04', 'MV5BY2E5NDQ5MjUtNTdkOC00OThhLThkNTgtOTQ2MWJhMmNiOGM2XkEyXkFqcGdeQXVyNTkzNjEwMjI@._V1_.jpg', 27, 36),
(21, '', 'Bunga teratai merupakan bunga yang mampu hidup di atas air. Bunga yang juga dikenal dengan nama lotus ini banyak digunakan sebagai hiasan di kolam.  Baca artikel wolipop, \"Mengenal Bunga Teratai, Ciri, Jenis, dan Manfaatnya\" selengkapnya https://wolipop.detik.com/home/d-6950966/mengenal-bunga-teratai-ciri-jenis-dan-manfaatnya.', '2024-04-17', '745-2.jpg', 29, 38),
(26, '', 'e3we', '2024-04-17', '1.jfif', 29, 38),
(30, '', 'segar enak', '2024-04-17', 'salad.jfif', 31, 42),
(29, 'gouuhyahbg', 'segar enak', '2024-04-17', 'gambar/1680262980_waf.jpg', 27, 43);

-- --------------------------------------------------------

--
-- Table structure for table `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(47, 30, 42, 'etef', '2024-04-17'),
(46, 30, 43, 'sefer ciksss', '2024-04-17'),
(45, 30, 42, 'www', '2024-04-17'),
(44, 29, 43, 'www', '2024-04-17'),
(43, 43, 29, 'www', '2024-04-17'),
(42, 43, 29, 'etef', '2024-04-17'),
(41, 41, 29, '', '2024-04-17'),
(39, 29, 43, 'etef', '2024-04-17'),
(38, 28, 43, 'etef', '2024-04-17'),
(48, 31, 43, 'etef', '2024-04-17'),
(49, 31, 42, 'www', '2024-04-17'),
(50, 29, 43, 'qqq', '2024-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(134, 30, 42, '2024-04-17'),
(133, 31, 42, '2024-04-17'),
(132, 29, 43, '2024-04-17'),
(131, 31, 43, '2024-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `Email`, `NamaLengkap`, `gambar`, `deskripsi`, `level`) VALUES
(43, '1', 'c4ca4238a0b923820dcc509a6f75849b', 'anismuthia@gmail.com', 'ariilwithout-l', '', '', 'user'),
(42, '2', 'c81e728d9d4c2f636f067f89cc14862c', 'rohma@gmail.com', 'ariilforeach', '', 'lorem supoiuahaggagaga', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`),
  ADD KEY `FotoID` (`FotoID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`),
  ADD KEY `FotoID` (`FotoID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
